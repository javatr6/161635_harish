package org.cap.demo;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {
	private static EntityManager em;

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		
		transaction.begin();

		Customer c1=new Customer("1001", "Ravi", "1000", new Date());
		/*Customer c2=new Customer("1002", "Amit", "2000", new Date("20-10-1995"));
		Customer c3=new Customer("1003", "Nitish","3000",new Date("08-01-1996"));*/
		
		em.persist(c1);
		/*em.persist(c2);
		em.persist(c3);*/

		transaction.commit();
	}



	
}

