package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.bean.LoginBean;

public class LoginDaoImpl  implements ILoginDao{

	@Override
	public boolean isValidLogin(LoginBean bean) {
		String sql="select * from users where username=? and password=?";

		try (
				Connection con=getConnection();	
				PreparedStatement ps=con.prepareStatement(sql);){
			ps.setString(1, bean.getUsername());
			ps.setString(2, bean.getPassword());
			ResultSet resultSet= ps.executeQuery(sql);	
			if(resultSet.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return false;
	}
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");//register driver
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException e )	{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}


}
