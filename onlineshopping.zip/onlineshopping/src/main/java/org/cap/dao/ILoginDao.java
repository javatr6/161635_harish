package org.cap.dao;

import org.cap.bean.LoginBean;

public interface ILoginDao {

	public abstract boolean isValidLogin(LoginBean bean);
}
